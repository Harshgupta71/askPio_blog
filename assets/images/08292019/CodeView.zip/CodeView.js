{
    "definition": {
        "$schema": "https://schema.management.azure.com/providers/Microsoft.Logic/schemas/2016-06-01/workflowdefinition.json#",
        "actions": {
            "Parse_JSON": {
                "inputs": {
                    "content": "@triggerBody()",
                    "schema": {
                        "properties": {
                            "access_token": {
                                "type": "string"
                            },
                            "expires_in": {
                                "type": "string"
                            },
                            "expires_on": {
                                "type": "string"
                            },
                            "ext_expires_in": {
                                "type": "string"
                            },
                            "not_before": {
                                "type": "string"
                            },
                            "resource": {
                                "type": "string"
                            },
                            "token_type": {
                                "type": "string"
                            }
                        },
                        "type": "object"
                    }
                },
                "runAfter": {},
                "type": "ParseJson"
            },
            "Restart_App_(HTTP)": {
                "inputs": {
                    "headers": {
                        "Authorization": "Bearer @{body('Parse_JSON')?['access_token']}",
                        "Content-Type": "application/json"
                    },
                    "method": "POST",
                    "uri": "https://management.azure.com/subscriptions/{subscription_id}/resourceGroups/{resource_group}/providers/Microsoft.Web/sites/{webApp_name}/restart?api-version=2016-08-01"
                },
                "runAfter": {
                    "Parse_JSON": [
                        "Succeeded"
                    ]
                },
                "type": "Http"
            }
        },
        "contentVersion": "1.0.0.0",
        "outputs": {},
        "parameters": {},
        "triggers": {
            "Get_Access_Token (HTTP)": {
                "inputs": {
                    "body": "grant_type=client_credentials&client_id={client_id}&client_secret={client_secret}&resource=https://management.core.windows.net/",
                    "headers": {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    "method": "POST",
                    "uri": "https://login.microsoftonline.com/{tenant_id}/oauth2/token"
                },
                "recurrence": {
                    "frequency": "Month",
                    "interval": 1
                },
                "type": "Http"
            }
        }
    }
}